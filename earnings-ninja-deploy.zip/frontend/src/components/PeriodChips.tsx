import { useTheme } from '../lib/themeContext';

export type Period = 'today' | 'yesterday' | 'week' | 'last7' | 'month' | 'lastMonth';

interface PeriodChipsProps {
  selected: Period;
  onSelect: (period: Period) => void;
  onSearchClick?: () => void;
}

export function PeriodChips({ selected, onSelect, onSearchClick }: PeriodChipsProps) {
  const { config } = useTheme();
  
  const periods: { value: Period; label: string }[] = [
    { value: 'today', label: 'Today' },
    { value: 'yesterday', label: 'Yesterday' },
    { value: 'week', label: 'This Week' },
    { value: 'last7', label: 'Last 7 Days' },
    { value: 'month', label: 'This Month' },
    { value: 'lastMonth', label: 'Last Month' },
  ];

  return (
    <div className="flex gap-1 md:gap-2 overflow-x-auto px-1 items-center">
      {periods.map((period) => (
        <button
          key={period.value}
          onClick={() => onSelect(period.value)}
          className={`px-2 md:px-4 py-1.5 md:py-2 rounded-lg md:rounded-xl text-xs md:text-sm whitespace-nowrap touch-manipulation transition-all ${
            selected === period.value
              ? `${config.chipActiveBg} ${config.chipActive} font-bold`
              : `${config.chipInactive} font-bold`
          }`}
        >
          {period.label}
        </button>
      ))}
    </div>
  );
}
