import { useTheme } from '../lib/themeContext';

interface ScrollToTopButtonProps {
  isFormOpen?: boolean;
}

export function ScrollToTopButton({ isFormOpen = false }: ScrollToTopButtonProps) {
  const { theme } = useTheme();
  const isDarkTheme = theme === 'ninja-dark';

  const scrollToPerformanceOverview = () => {
    // Find the performance overview element
    const performanceOverview = document.getElementById('performance-overview');
    
    if (performanceOverview) {
      // Scroll the element into view smoothly, centered to avoid header overlap on mobile
      performanceOverview.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    } else {
      // Fallback: scroll to top if element not found
      const targets = [
        document.querySelector('.overflow-y-auto') as HTMLElement | null,
        document.documentElement,
        document.body,
        window
      ];

      for (const target of targets) {
        if (target) {
          if (target === window) {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          } else {
            target.scrollTo({ top: 0, behavior: 'smooth' });
          }
        }
      }
    }
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLButtonElement>) => {
    // Ensure touch events work smoothly on mobile
    (e.currentTarget as HTMLButtonElement).style.opacity = '1';
  };

  const handleTouchEnd = () => {
    setTimeout(() => {
      const btn = document.querySelector('[aria-label="Scroll to top"]') as HTMLButtonElement | null;
      if (btn) {
        btn.style.opacity = '';
      }
    }, 150);
  };

  return (
    <>
        <button
          onClick={scrollToPerformanceOverview}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          className={`fixed right-3 md:right-5 bottom-20 md:bottom-44 z-50 p-2 md:p-3 rounded-full shadow-lg transition-all active:scale-95 active:opacity-100 hover:opacity-100 opacity-60 md:opacity-40 md:hover:scale-110 touch-action-manipulation cursor-pointer bg-gradient-to-br from-yellow-300 to-yellow-400 text-slate-900 border-2 border-yellow-200 hover:from-yellow-400 hover:to-yellow-500`}
          aria-label="Scroll to Performance Overview"
          title="Scroll to Performance Overview"
          style={{ touchAction: 'manipulation', WebkitTouchCallout: 'none' }}
        >
          <svg className="w-5 md:w-6 h-5 md:h-6 font-bold" fill="currentColor" viewBox="0 0 24 24">
            <path d="M7 16l-4-4m0 0l4-4m-4 4h18" transform="rotate(90 12 12)" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} />
          </svg>
        </button>
    </>
  );
}
