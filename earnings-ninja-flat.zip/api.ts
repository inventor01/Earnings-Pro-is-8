const API_BASE = import.meta.env.VITE_API_BASE || '';

// Get token from localStorage
function getAuthToken(): string | null {
  return localStorage.getItem('auth_token');
}

// Helper to add auth header to fetch options
function getAuthHeaders(): Record<string, string> {
  const token = getAuthToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export type EntryType = 'ORDER' | 'BONUS' | 'EXPENSE' | 'CANCELLATION';
export type AppType = 'DOORDASH' | 'UBEREATS' | 'INSTACART' | 'GRUBHUB' | 'SHIPT' | 'OTHER';
export type ExpenseCategory = 'GAS' | 'PARKING' | 'TOLLS' | 'MAINTENANCE' | 'PHONE' | 'SUBSCRIPTION' | 'FOOD' | 'LEISURE' | 'OTHER';
export type TimeframeType = 'TODAY' | 'YESTERDAY' | 'THIS_WEEK' | 'LAST_7_DAYS' | 'THIS_MONTH' | 'LAST_MONTH' | 'SAVINGS_GOAL';

export interface Entry {
  id: number;
  timestamp: string;
  type: EntryType;
  app: AppType;
  order_id?: string;
  amount: number;
  distance_miles: number;
  duration_minutes: number;
  category?: ExpenseCategory;
  note?: string;
  receipt_url?: string;
  is_business_expense?: boolean;
  during_business_hours?: boolean;
  created_at: string;
  updated_at: string;
}

export interface EntryCreate {
  timestamp?: string;
  date?: string;
  time?: string;
  type: EntryType;
  app: AppType;
  order_id?: string;
  amount: number;
  distance_miles?: number;
  duration_minutes?: number;
  category?: ExpenseCategory;
  note?: string;
  receipt_url?: string;
  is_business_expense?: boolean;
  during_business_hours?: boolean;
}

export const getCategoryEmoji = (category: ExpenseCategory): string => {
  switch (category) {
    case 'GAS': return '⛽';
    case 'PARKING': return '🅿️';
    case 'TOLLS': return '🛣️';
    case 'MAINTENANCE': return '🔧';
    case 'PHONE': return '📱';
    case 'SUBSCRIPTION': return '📦';
    case 'FOOD': return '🍔';
    case 'LEISURE': return '🎮';
    case 'OTHER': return '📋';
    default: return '📋';
  }
};

export interface Settings {
  cost_per_mile: number;
}

export interface Goal {
  id: number;
  timeframe: TimeframeType;
  target_profit: number;
  goal_name: string;
  created_at: string;
  updated_at: string;
}

export interface Rollup {
  revenue: number;
  expenses: number;
  profit: number;
  miles: number;
  hours: number;
  dollars_per_mile: number;
  dollars_per_hour: number;
  average_order_value: number;
  per_hour_first_to_last: number;
  by_type: Record<string, number>;
  by_app: Record<string, number>;
  goal?: Goal | null;
  goal_progress?: number | null;
}

export interface SuggestionResponse {
  suggestion: string;
  minimum_order: number | null;
  peak_time: string | null;
  average_order: number;
  total_orders: number;
  reasoning: string;
}

export const api = {
  async getHealth() {
    const res = await fetch(`${API_BASE}/api/health`);
    return res.json();
  },

  async getSettings(): Promise<Settings> {
    const res = await fetch(`${API_BASE}/api/settings`, {
      headers: getAuthHeaders(),
    });
    return res.json();
  },

  async updateSettings(settings: Settings): Promise<Settings> {
    const res = await fetch(`${API_BASE}/api/settings`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(settings),
    });
    return res.json();
  },

  async createEntry(entry: EntryCreate): Promise<Entry> {
    const res = await fetch(`${API_BASE}/api/entries`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(entry),
    });
    if (!res.ok) throw new Error('Failed to create entry');
    return res.json();
  },

  async getEntries(timeframe?: string, dayOffset?: number, limit = 100, cursor?: number): Promise<Entry[]> {
    const params = new URLSearchParams();
    if (timeframe) params.append('timeframe', timeframe);
    if (dayOffset !== undefined && dayOffset !== 0) params.append('day_offset', dayOffset.toString());
    params.append('limit', limit.toString());
    if (cursor) params.append('cursor', cursor.toString());
    
    const res = await fetch(`${API_BASE}/api/entries?${params}`, {
      headers: getAuthHeaders(),
    });
    return res.json();
  },

  async updateEntry(id: number, entry: Partial<EntryCreate>): Promise<Entry> {
    const res = await fetch(`${API_BASE}/api/entries/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(entry),
    });
    if (!res.ok) throw new Error('Failed to update entry');
    return res.json();
  },

  async deleteEntry(id: number): Promise<void> {
    const res = await fetch(`${API_BASE}/api/entries/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to delete entry');
  },

  async deleteAllEntries(): Promise<void> {
    const res = await fetch(`${API_BASE}/api/entries`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to delete all entries');
  },

  async getRollup(timeframe?: string, dayOffset?: number): Promise<Rollup> {
    const params = new URLSearchParams();
    if (timeframe) params.append('timeframe', timeframe);
    if (dayOffset !== undefined && dayOffset !== 0) params.append('day_offset', dayOffset.toString());
    
    const res = await fetch(`${API_BASE}/api/rollup?${params}`, {
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to fetch rollup');
    return res.json();
  },

  async getDashboardOverview(timeframe?: string, dayOffset?: number): Promise<{ entries: Entry[]; rollup: Rollup; timeframe: string }> {
    const params = new URLSearchParams();
    if (timeframe) params.append('timeframe', timeframe);
    if (dayOffset !== undefined && dayOffset !== 0) params.append('day_offset', dayOffset.toString());
    
    const res = await fetch(`${API_BASE}/api/dashboard/overview?${params}`, {
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to fetch dashboard overview');
    return res.json();
  },

  async createGoal(timeframe: TimeframeType, target_profit: number, goal_name?: string): Promise<Goal> {
    const res = await fetch(`${API_BASE}/api/goals`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ timeframe, target_profit, goal_name: goal_name || 'Savings Goal' }),
    });
    if (!res.ok) throw new Error('Failed to create goal');
    return res.json();
  },

  async getGoal(timeframe: TimeframeType): Promise<Goal | null> {
    try {
      const res = await fetch(`${API_BASE}/api/goals/${timeframe}`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) return null;
      return res.json();
    } catch {
      return null;
    }
  },

  async updateGoal(timeframe: TimeframeType, target_profit: number): Promise<Goal> {
    const res = await fetch(`${API_BASE}/api/goals/${timeframe}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ target_profit }),
    });
    if (!res.ok) throw new Error('Failed to update goal');
    return res.json();
  },

  async deleteGoal(timeframe: TimeframeType): Promise<void> {
    const res = await fetch(`${API_BASE}/api/goals/${timeframe}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to delete goal');
  },

  async getSuggestions(from?: string, to?: string): Promise<SuggestionResponse> {
    const params = new URLSearchParams();
    if (from) params.append('from_date', from);
    if (to) params.append('to_date', to);
    
    const res = await fetch(`${API_BASE}/api/suggestions?${params}`, {
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to fetch suggestions');
    return res.json();
  },

  async getSuggestionsOld(from?: string, to?: string) {
    const params = new URLSearchParams();
    if (from) params.append('from_date', from);
    if (to) params.append('to_date', to);
    
    const res = await fetch(`${API_BASE}/api/suggestions?${params}`);
    if (!res.ok) throw new Error('Failed to fetch suggestions');
    return res.json();
  },

  async getOAuthStatus(): Promise<Record<string, { connected: boolean; token_expires_at: string | null }>> {
    const res = await fetch(`${API_BASE}/api/oauth/status`);
    if (!res.ok) throw new Error('Failed to fetch OAuth status');
    return res.json();
  },

  async getUberAuthUrl(): Promise<{ auth_url: string }> {
    const res = await fetch(`${API_BASE}/api/oauth/uber/authorize`);
    if (!res.ok) throw new Error('Failed to get Uber auth URL');
    return res.json();
  },

  async getShiptAuthUrl(): Promise<{ auth_url: string }> {
    const res = await fetch(`${API_BASE}/api/oauth/shipt/authorize`);
    if (!res.ok) throw new Error('Failed to get Shipt auth URL');
    return res.json();
  },

  async disconnectPlatform(platform: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/api/oauth/${platform}/disconnect`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(`Failed to disconnect ${platform}`);
    return res.json();
  },

  async getUserPoints() {
    const res = await fetch(`${API_BASE}/api/points/user`);
    return res.json();
  },

  async dailyCheckIn() {
    const res = await fetch(`${API_BASE}/api/points/daily-check-in`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    return res.json();
  },

  async getRewards() {
    const res = await fetch(`${API_BASE}/api/points/rewards`);
    return res.json();
  },

  async importEntries(entries: EntryCreate[]): Promise<{ message: string; count: number; entries: Entry[] }> {
    const res = await fetch(`${API_BASE}/api/entries/import`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(entries),
    });
    if (!res.ok) throw new Error('Failed to import entries');
    return res.json();
  },
};
