from sqlalchemy.orm import Session
from sqlalchemy import func
from backend.models import Entry, Settings, EntryType, AppType, Goal, TimeframeType
from decimal import Decimal
from datetime import datetime
from typing import Optional

def calculate_rollup(db: Session, from_date: Optional[datetime] = None, to_date: Optional[datetime] = None, timeframe: Optional[str] = None, user_id: Optional[str] = None):
    # Build efficient SQL query with aggregations
    query = db.query(Entry)
    
    if user_id:
        query = query.filter(Entry.user_id == user_id)
    if from_date:
        query = query.filter(Entry.timestamp >= from_date)
    if to_date:
        query = query.filter(Entry.timestamp <= to_date)
    
    # Fetch entries first for by_type and by_app calculations
    entries = query.all()
    
    settings = db.query(Settings).filter(Settings.user_id == user_id).first() if user_id else db.query(Settings).first()
    cost_per_mile = settings.cost_per_mile if settings else Decimal("0")
    
    total_amount = Decimal("0")
    revenue = Decimal("0")
    expenses = Decimal("0")
    miles = 0.0
    total_minutes = 0
    
    by_type = {t.value: Decimal("0") for t in EntryType}
    by_app = {a.value: Decimal("0") for a in AppType}
    
    for entry in entries:
        amount = Decimal(str(entry.amount))
        total_amount += amount
        
        if amount > 0:
            revenue += amount
        else:
            expenses += abs(amount)
        
        miles += entry.distance_miles
        total_minutes += entry.duration_minutes
        
        by_type[entry.type.value] += amount
        by_app[entry.app.value] += amount
    
    hours = total_minutes / 60.0 if total_minutes > 0 else 0.0
    net_earnings = total_amount
    profit = total_amount
    
    dollars_per_mile = net_earnings / Decimal(str(miles)) if miles > 0 else Decimal("0")
    
    # Calculate metrics for orders
    order_entries = [e for e in entries if e.type.value == 'ORDER']
    order_count = len(order_entries)
    average_order_value = Decimal("0")
    dollars_per_hour = Decimal("0")
    
    # Calculate per-hour rate based on earliest and latest entries in timeframe
    if entries:
        total_order_revenue = Decimal("0")
        for order in order_entries:
            total_order_revenue += Decimal(str(order.amount))
        if order_count > 0:
            average_order_value = total_order_revenue / Decimal(str(order_count))
        
        # Get earliest and latest timestamps from ALL entries in the timeframe
        all_timestamps = sorted([e.timestamp for e in entries])
        first_timestamp = all_timestamps[0]
        last_timestamp = all_timestamps[-1]
        
        hours_first_to_last = (last_timestamp - first_timestamp).total_seconds() / 3600.0
        
        # Calculate hourly rate
        if hours_first_to_last > 0:
            # If under 1 hour, use total revenue as the $/hour rate
            if hours_first_to_last < 1.0:
                dollars_per_hour = revenue
            else:
                # If 1+ hours, calculate based on profit / time elapsed
                dollars_per_hour = profit / Decimal(str(hours_first_to_last))
        else:
            dollars_per_hour = Decimal("0")
    else:
        # No entries at all
        dollars_per_hour = Decimal("0")
    
    # Get goal data if timeframe provided
    goal_data = None
    goal_progress = None
    if timeframe and user_id:
        try:
            tf = TimeframeType[timeframe]
            goal = db.query(Goal).filter(Goal.timeframe == tf, Goal.user_id == user_id).first()
            if goal:
                goal_data = {
                    "id": goal.id,
                    "timeframe": goal.timeframe.value,
                    "target_profit": float(goal.target_profit),
                    "goal_name": goal.goal_name,
                    "created_at": goal.created_at.isoformat(),
                    "updated_at": goal.updated_at.isoformat()
                }
                target = float(goal.target_profit)
                if target > 0:
                    # Calculate goal progress based on PROFIT, not revenue
                    goal_progress = min(100.0, (float(profit) / target) * 100)
        except (KeyError, ValueError):
            pass
    
    return {
        "revenue": float(revenue),
        "expenses": float(expenses),
        "profit": float(profit),
        "miles": miles,
        "hours": round(hours, 2),
        "dollars_per_mile": float(round(dollars_per_mile, 2)),
        "dollars_per_hour": float(round(dollars_per_hour, 2)),
        "average_order_value": float(round(average_order_value, 2)),
        "by_type": {k: float(v) for k, v in by_type.items()},
        "by_app": {k: float(v) for k, v in by_app.items()},
        "goal": goal_data,
        "goal_progress": goal_progress
    }
